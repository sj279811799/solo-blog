title: 基于Docker安装Solo博客
date: '2019-11-20 00:09:35'
updated: '2019-11-20 00:09:35'
tags: [solo安装, docker, nginx]
permalink: /articles/2019/11/20/1574179775199.html
---
> 首先请先安装好docker和nginx，教程后面补上。

## 拉取镜像

这一步不是必需的，因为docker run的时候如果镜像不存在，会自动拉取镜像。

```
docker pull b3log/solo
docker pull mysql:5.7
```

## 运行mysql

注意修改root密码。如果要修改访问端口，可以修改前面的，我这里设置成了3308。mysql的数据卷绑定到了主机的~/volume/mysql目录。

```
docker run -p 3308:3306 -v ~/volume/mysql/:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=root -d mysql:5.7
```

## 创建数据库

库名solo，字符集utf8mb4，排序规则utf8mb4_general_ci。

这一步我是在Navicat上操作的，sql后面补上。

## 运行solo

我安装过程中，复制命令导致--写成了—，导致安装后访问不了，这里要注意下。

```
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="root" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3308/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=http --server_host=blog.bughub.top --server_port=8080
```

## 配置nginx

```
# 指定应用访问地址
upstream blog_pool {
    server localhost:8080;
}

server {
    listen       80; # 监听端口
    server_name  blog.bughub.top; # 监听域名
    access_log off;

    # 将所有请求转发给blog_pool池的应用处理
    location / {
	proxy_pass http://blog_pool$request_uri;
	proxy_set_header  Host $host:$server_port;
        proxy_set_header  X-Real-IP  $remote_addr;
	client_max_body_size  10m;
    }
}
```

